@echo off
setlocal
set "APP=%~dp0ChromePanelFix_9.1_GUI-OPERATIVO.ps1"
if not exist "%APP%" (
  echo ERROR: No se encuentra ChromePanelFix_9.1_GUI-OPERATIVO.ps1.
  echo Extraiga todos los archivos del ZIP en una misma carpeta.
  pause
  exit /b 2
)
set "CHROMEPANELFIX_SCRIPT=%APP%"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -Command "$blocked = @(Get-ChildItem -LiteralPath (Split-Path -LiteralPath $env:CHROMEPANELFIX_SCRIPT) -Filter '*.ps1' -File | Where-Object { Get-Item -LiteralPath $_.FullName -Stream Zone.Identifier -ErrorAction SilentlyContinue }); if ($blocked.Count -gt 0) { exit 10 }"
if errorlevel 10 (
  echo.
  echo Windows marca scripts de esta carpeta como descargados de Internet.
  echo En el ZIP: clic derecho, Propiedades, marque Desbloquear y pulse Aplicar.
  echo Extraiga de nuevo el ZIP en una carpeta limpia.
  echo No se ha cambiado la politica de ejecucion de PowerShell.
  pause
  exit /b 3
)
if errorlevel 1 (
  echo.
  echo ERROR: No se pudo comprobar si Windows bloqueo los scripts.
  echo Ejecute la comprobacion desde Windows PowerShell 5.1 y consulte al administrador.
  pause
  exit /b 4
)
start "" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -WindowStyle Hidden -Command "try { & $env:CHROMEPANELFIX_SCRIPT } catch { Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show(('No se pudo iniciar ChromePanelFix 9.1.' + [Environment]::NewLine + [Environment]::NewLine + [string]$_.Exception.Message + [Environment]::NewLine + [Environment]::NewLine + 'Si los archivos proceden de una descarga, desbloquee el ZIP en Propiedades antes de extraerlo. Respete la politica de ejecucion de su organizacion.'), 'ChromePanelFix 9.1', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error); exit 1 } # ChromePanelFix-9.1-PRUEBA-CIERRE"
exit /b