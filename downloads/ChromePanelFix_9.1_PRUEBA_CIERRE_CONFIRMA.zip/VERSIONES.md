# Política de versiones

- 9.1 GUI OPERATIVO corrige la distribución del lanzador 9.0.
- 9.0 sigue disponible en Releases como primera edición pública.
- 8.0 GUI OPERATIVO permanece como referencia local congelada. No editar su carpeta, ZIP o manifiestos.
- 6.0 también permanece congelada.
- No reutilizar identificadores ni ZIP publicados para contenido diferente.
- Cada entrega nueva recibe una versión, notas y huellas propias.

## Copia local de prueba de 9.1
No publicada ni etiquetada como version nueva. Se usa solo para validar el cierre de procesos MMC/PowerShell. La Release v9.1 oficial permanece intacta.
