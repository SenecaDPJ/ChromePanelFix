﻿NOTA: Este archivo describe la Release oficial 9.1. La carpeta actual es una compilacion local de prueba, no publicada, y no representa el ZIP de esa Release.

# Publicación de ChromePanelFix 9.1

- Repositorio: https://github.com/SenecaDPJ/ChromePanelFix
- Versión: 9.1 GUI OPERATIVO, hotfix de distribución sobre 9.0.
- Mantenedor: SenecaDPJ.
- Licencia: MIT.
- Sistema: Windows Server; PowerShell 5.1.

El ZIP contiene la interfaz, el motor, las instrucciones y el lanzador. Extraiga los archivos y abra Abrir-ChromePanelFix.cmd. Si Windows marca scripts como descargados, el lanzador pedirá confirmación y retirará Zone.Identifier únicamente de los .ps1 de esta carpeta. No se modifica ni omite la política de ejecución de la organización.

La eficacia de la tarea automática y la compatibilidad con Windows Server 2016 siguen pendientes. La versión 9.0 se conserva en el historial de Releases.