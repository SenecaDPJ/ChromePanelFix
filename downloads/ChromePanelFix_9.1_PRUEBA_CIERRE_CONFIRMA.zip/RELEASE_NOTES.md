﻿LOCAL TEST COPY — NOT A GITHUB RELEASE. Based on published 9.1; the official v9.1 ZIP is unchanged.

# ChromePanelFix 9.1 — GUI OPERATIVO

Corrección de distribución para Windows:

- El lanzador CMD se guarda en ASCII/CRLF, sin BOM UTF-8.
- Los errores de inicio de PowerShell se muestran en un aviso legible.
- La copia privada de prueba pregunta antes de retirar Zone.Identifier de los scripts extraídos; no altera la política de ejecución.
- Se mantiene la política de ejecución de la organización; el lanzador no usa -ExecutionPolicy Bypass.
- No cambia el motor de reparación ni la funcionalidad de 9.0.

Pendiente de validación: eficacia automática de la tarea y compatibilidad con Windows Server 2016.

Local-only change: release MMC COM references after opening Task Scheduler, and include a PID-confirmed process stop helper.
Private test-copy update: the CMD launcher asks for confirmation before removing Zone.Identifier from extracted PowerShell scripts. It leaves execution policy unchanged.
