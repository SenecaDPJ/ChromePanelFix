﻿# Historial

## 9.1
Corrige la codificación BOM del lanzador CMD y muestra errores de inicio que antes quedaban ocultos. La copia privada de prueba añade una confirmación interactiva para retirar Zone.Identifier de los scripts extraídos. No elude la política de ejecución de PowerShell.

## 9.0
Primera edición de ChromePanelFix publicada en GitHub, clon funcional de 8.0.

## 8.0
GUI OPERATIVO, última base validada y congelada localmente.
## Prueba local basada en 9.1 — no publicada
Libera referencias COM de MMC y añade un cierre de procesos ChromePanelFix limitado a PID confirmados. No se modifica ni se reemplaza la Release oficial v9.1.

## Copia privada de prueba — confirmación interactiva
El lanzador revisa Zone.Identifier antes de iniciar la GUI. Si encuentra scripts marcados, pide confirmación; solo si el usuario acepta ejecuta Unblock-File sobre los .ps1 de esta carpeta y continúa. Si rechaza o falla, no inicia la GUI. No cambia la política de ejecución.
